package com.util;

public class Exception404 extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8203384996689189820L;

}
